#!/bin/bash
python greeting_arg.py -n $1 -g $2
